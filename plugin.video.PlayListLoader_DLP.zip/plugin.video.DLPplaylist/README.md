# Kodi-plugin.video.blackarrowplaylist
Taking ownership of plugin.video.blackarrowplaylist previously owned by Avigdork
See: https://github.com/flechanegra/matrix
